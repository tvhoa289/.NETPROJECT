﻿namespace Umbraco.Core
{
    /// <summary>
    /// Constants all the identifiers within the Umbraco core.
    /// </summary>
    public static partial class Constants
    {
        // generic constants can go here
    }
}
