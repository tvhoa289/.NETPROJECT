﻿namespace Umbraco.Core.Dictionary
{
    public interface ICultureDictionaryFactory
    {
        ICultureDictionary CreateDictionary();
    }
}
