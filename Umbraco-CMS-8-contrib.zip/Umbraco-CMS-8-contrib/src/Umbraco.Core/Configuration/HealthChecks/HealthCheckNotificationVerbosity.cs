﻿namespace Umbraco.Core.Configuration.HealthChecks
{
    public enum HealthCheckNotificationVerbosity
    {
        Summary,
        Detailed
    }
}
