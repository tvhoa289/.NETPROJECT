﻿namespace Umbraco.Core.Configuration.UmbracoSettings
{
    public interface IChar
    {
        string Char { get; }
        string Replacement { get; }
    }
}
