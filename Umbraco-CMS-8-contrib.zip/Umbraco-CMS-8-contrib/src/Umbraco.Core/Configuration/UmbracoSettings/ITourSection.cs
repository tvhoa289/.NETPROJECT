﻿namespace Umbraco.Core.Configuration.UmbracoSettings
{
    public interface ITourSection
    {
        bool EnableTours { get; }
    }
}