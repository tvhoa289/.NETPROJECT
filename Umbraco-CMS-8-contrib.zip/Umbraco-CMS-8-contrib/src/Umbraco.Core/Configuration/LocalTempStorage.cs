namespace Umbraco.Core.Configuration
{
    public enum LocalTempStorage
    {
        Unknown = 0,
        Default,
        AspNetTemp,
        EnvironmentTemp
    }
}
