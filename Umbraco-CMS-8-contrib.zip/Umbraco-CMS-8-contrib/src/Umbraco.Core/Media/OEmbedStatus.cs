﻿namespace Umbraco.Core.Media
{
    public enum OEmbedStatus
    {
        NotSupported,
        Error,
        Success
    }
}
