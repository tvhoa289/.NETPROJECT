﻿namespace Umbraco.Core.Composing
{
    public interface IDiscoverable
    { }
}
