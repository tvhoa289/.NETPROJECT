﻿namespace Umbraco.Core.Deploy
{
    public enum Direction
    {
        ToArtifact,
        FromArtifact
    }
}
