﻿namespace Umbraco.Core.Logging.Viewer
{
    public class LogTemplate
    {
        public string MessageTemplate { get; set; }

        public int Count { get; set; }
    }
}
