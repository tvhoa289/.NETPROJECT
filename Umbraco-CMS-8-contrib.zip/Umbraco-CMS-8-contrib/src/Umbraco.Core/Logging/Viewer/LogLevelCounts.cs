﻿namespace Umbraco.Core.Logging.Viewer
{
    public class LogLevelCounts
    {
        public int Information { get; set; }

        public int Debug { get; set; }

        public int Warning { get; set; }

        public int Error { get; set; }

        public int Fatal { get; set; }
    }
}
