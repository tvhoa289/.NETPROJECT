﻿using Umbraco.Core.Composing;

namespace Umbraco.Core.Compose
{
    public sealed class AuditEventsComposer : ComponentComposer<AuditEventsComponent>, ICoreComposer
    { }
}
