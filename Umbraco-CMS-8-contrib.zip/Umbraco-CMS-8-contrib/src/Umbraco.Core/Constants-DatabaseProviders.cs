﻿namespace Umbraco.Core
{
    public static partial class Constants
    {
        public static class DatabaseProviders
        {
            public const string SqlCe = "System.Data.SqlServerCe.4.0";
            public const string SqlServer = "System.Data.SqlClient";
        }
    }
}
