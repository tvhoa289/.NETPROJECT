﻿namespace Umbraco.Core.Migrations.Expressions.Common
{
    public interface IExecutableBuilder
    {
        /// <summary>
        /// Executes.
        /// </summary>
        void Do();
    }
}
