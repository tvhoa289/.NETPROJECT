﻿namespace Umbraco.Core.Events
{
    public interface IEventMessagesAccessor
    {
        EventMessages EventMessages { get; set; }
    }
}
