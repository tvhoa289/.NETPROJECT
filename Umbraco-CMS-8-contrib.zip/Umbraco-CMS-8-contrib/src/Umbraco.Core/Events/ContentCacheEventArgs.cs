﻿namespace Umbraco.Core.Events
{
    public class ContentCacheEventArgs : System.ComponentModel.CancelEventArgs { }
}
