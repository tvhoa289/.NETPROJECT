﻿namespace Umbraco.Core.Events
{
    internal class DatabaseCreationEventArgs : System.ComponentModel.CancelEventArgs{}
}
