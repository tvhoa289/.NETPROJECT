﻿namespace Umbraco.Core.Events
{
    //public class RefreshContentEventArgs : System.ComponentModel.CancelEventArgs { }
}
