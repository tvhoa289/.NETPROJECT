﻿namespace Umbraco.Core.Events
{
    internal enum EventNameExtractorError
    {
        NoneFound,
        Ambiguous
    }
}
