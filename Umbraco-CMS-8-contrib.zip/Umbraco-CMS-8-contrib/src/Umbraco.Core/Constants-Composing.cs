﻿namespace Umbraco.Core
{
    /// <summary>
    /// Defines constants.
    /// </summary>
    public static partial class Constants
    {
        /// <summary>
        /// Defines constants for composition.
        /// </summary>
        public static class Composing
        { }
    }
}
