
# Umbraco c# API reference

## Quick Links:

### [Umbraco.Core](api/Umbraco.Core.html) docs
### [Umbraco.Web](api/Umbraco.Web.html) docs
